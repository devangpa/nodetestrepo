  
const User = require('./../models/userModel');