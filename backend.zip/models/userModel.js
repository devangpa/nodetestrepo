const mongoose = require('mongoose');
const validator = require('validator');

const userSchema = new mongoose.Schema({
    name:{
        type: String,
        required: [true, 'Please Tell Us Your Name']
    },
    email:{
        type: String,
        required: [true, 'Please provide your email'],
        unique:[true,'Email Address  All ready Exit'],
        lowercase: true,
        validate: [validator.isEmail, 'Please provide a valid email']
    },
    photo: String,
    role: {
        type: String,
        default: ''
      },
    mobile:{
        type: Number,
        required: [true, 'Please provied mobile number'],
    }
})
const User = mongoose.model('User', userSchema);

module.exports = User;