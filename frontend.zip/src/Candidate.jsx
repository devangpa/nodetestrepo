import React from 'react'
const Candidate=( props )=> {
    return (
        <div>
            <h2>Candidate</h2>
            <h1>{props.useridentity}</h1> 
        </div>
    )
}

export default Candidate