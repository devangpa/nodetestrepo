import React from 'react'
const Recruiter=( props )=> {
    return (
        <div>
            <h2>Recrutor</h2>
            <h1>{props.useridentity}</h1>
            
        </div>
    )
}

export default Recruiter